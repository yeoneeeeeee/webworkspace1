package com.kh.board.model.vo;

public class Reply {

}
